import React, { useState, useEffect, useMemo } from 'react';
import {
  fetchDailyPicks,
  FetchProgress,
  getTodayDateString,
  SAMPLE_FALLBACK_PICKS,
  RAPID_API_HOST,
} from './services/apiSports';
import { ProcessedPick } from './types';
import { PickCard } from './components/PickCard';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import {
  Search,
  Sparkles,
  Calendar,
  AlertCircle,
  RefreshCw,
  SlidersHorizontal,
  Flame,
  CheckCircle,
  Info,
  ShieldCheck,
  TrendingUp,
  Percent,
  Download,
} from 'lucide-react';

export default function App() {
  const [selectedDate, setSelectedDate] = useState<string>(() => getTodayDateString());
  const [picks, setPicks] = useState<ProcessedPick[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [progress, setProgress] = useState<FetchProgress | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('todos');
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  // Check for cached picks on load
  useEffect(() => {
    try {
      const cached = localStorage.getItem(`tu_pronosticos_${selectedDate}`);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setPicks(parsed);
          setHasSearched(true);
        }
      }
    } catch {
      // ignore
    }
  }, [selectedDate]);

  const handleBuscarPronosticos = async (dateToSearch?: string) => {
    const targetDate = dateToSearch || selectedDate;
    setIsLoading(true);
    setErrorMessage(null);
    setHasSearched(true);

    try {
      const result = await fetchDailyPicks(targetDate, (p) => {
        setProgress(p);
      });

      if (result.picks && result.picks.length > 0) {
        setPicks(result.picks);
        if (result.error) {
          setErrorMessage(result.error);
        }
      } else {
        // If no picks found via live API (or rate limit reached), notify user and provide graceful option
        setPicks([]);
        setErrorMessage(
          result.error ||
            `No se encontraron partidos con cuota ≥ 1.50 para la fecha ${targetDate}. Puedes probar con otra fecha o cargar pronósticos de muestra.`
        );
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al conectar con el servicio de pronósticos';
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoadSamplePicks = () => {
    setPicks(SAMPLE_FALLBACK_PICKS);
    setHasSearched(true);
    setErrorMessage(null);
  };

  // Filter picks
  const filteredPicks = useMemo(() => {
    if (activeFilter === 'local') {
      return picks.filter((p) => p.pick.includes('Local'));
    }
    if (activeFilter === 'visita') {
      return picks.filter((p) => p.pick.includes('Visita'));
    }
    if (activeFilter === 'btts') {
      return picks.filter((p) => p.market.includes('Ambos Equipos') || p.pick.includes('Ambos'));
    }
    if (activeFilter === 'over') {
      return picks.filter((p) => p.market.includes('Total') || p.pick.includes('Over'));
    }
    return picks;
  }, [picks, activeFilter]);

  // Combined stats
  const averageOdd = useMemo(() => {
    if (picks.length === 0) return 0;
    const sum = picks.reduce((acc, p) => acc + p.cuota, 0);
    return (sum / picks.length).toFixed(2);
  }, [picks]);

  const combinedOdd = useMemo(() => {
    if (picks.length === 0) return '0.00';
    const mult = picks.reduce((acc, p) => acc * p.cuota, 1);
    return mult.toFixed(2);
  }, [picks]);

  // Format date readable in Spanish
  const readableDate = useMemo(() => {
    try {
      const [y, m, d] = selectedDate.split('-').map(Number);
      const dateObj = new Date(y, m - 1, d);
      return dateObj.toLocaleDateString('es-ES', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });
    } catch {
      return selectedDate;
    }
  }, [selectedDate]);

  return (
    <div className="min-h-screen bg-[#0d0d0d] text-white flex flex-col font-sans selection:bg-[#0DBF4B]/30 selection:text-white">
      {/* Offline Status */}
      <OfflineIndicator />

      {/* Top Navbar */}
      <header className="sticky top-0 z-40 bg-[#0d0d0d]/90 backdrop-blur-md border-b border-white/10 px-4 py-3 md:px-8">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#1e1e22] border border-[#0DBF4B]/40 flex items-center justify-center shadow-lg shadow-[#0DBF4B]/10">
              <span className="text-base font-black text-[#0DBF4B]">TP</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg md:text-xl font-black tracking-tight text-white">
                  Tu Pronosticos
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#0DBF4B]/15 text-[#0DBF4B] border border-[#0DBF4B]/30">
                  <Flame className="w-3 h-3" /> IA & Stats
                </span>
              </div>
              <p className="text-[11px] text-gray-400 hidden sm:block">
                Cuotas ≥ 1.50 • Prioridad 1X2, BTTS & Over 2.5
              </p>
            </div>
          </div>

          {/* Action Center & PWA Install Button */}
          <div className="flex items-center gap-2.5">
            <a
              id="btn-download-zip"
              href="/tu-pronosticos.zip"
              download="tu-pronosticos.zip"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-white/10 hover:bg-white/20 text-white border border-white/20 transition shadow-sm cursor-pointer"
              title="Descargar código del proyecto en archivo .ZIP"
            >
              <Download className="w-3.5 h-3.5 text-[#0DBF4B]" />
              <span className="hidden xs:inline sm:inline">Descargar ZIP</span>
              <span className="xs:hidden sm:hidden">ZIP</span>
            </a>

            <PWAInstallButton />

            <div className="hidden lg:flex items-center gap-1.5 text-xs text-gray-400 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">
              <ShieldCheck className="w-3.5 h-3.5 text-[#0DBF4B]" />
              <span>{RAPID_API_HOST}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6 md:py-8 flex flex-col gap-6">
        {/* Date Selector & Search Control Panel */}
        <section
          id="search-control-panel"
          className="bg-[#1e1e22] border border-white/10 p-5 md:p-8 shadow-2xl relative overflow-hidden"
          style={{ borderRadius: '15px' }}
        >
          {/* Subtle decorative background glow */}
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#0DBF4B]/5 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col items-center text-center max-w-3xl mx-auto gap-5">
            {/* Title & Badge */}
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-gray-300">
                <Calendar className="w-3.5 h-3.5 text-[#0DBF4B]" />
                <span className="capitalize">{readableDate}</span>
              </div>
              <h2 className="text-2xl md:text-3xl lg:text-4xl font-black text-white tracking-tight">
                Pronósticos de Fútbol Hoy
              </h2>
              <p className="text-sm md:text-base text-gray-400 max-w-xl mx-auto">
                Algoritmo matemático con datos de <strong className="text-gray-300">API-Sports</strong>.
                Filtra cuotas de valor <strong className="text-[#F59E0B]">≥ 1.50</strong> priorizando
                victorias con más del 50% de probabilidad, Ambos Marcan y Over 2.5.
              </p>
            </div>

            {/* Date Quick Switcher */}
            <div className="flex flex-wrap items-center justify-center gap-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  const today = getTodayDateString();
                  setSelectedDate(today);
                }}
                className={`px-3 py-1.5 rounded-lg border font-medium transition cursor-pointer ${
                  selectedDate === getTodayDateString()
                    ? 'bg-[#0DBF4B]/20 border-[#0DBF4B] text-[#0DBF4B] font-bold'
                    : 'bg-black/40 border-white/10 text-gray-400 hover:text-white'
                }`}
              >
                Hoy
              </button>

              <label className="flex items-center gap-1.5 bg-black/40 border border-white/10 px-3 py-1.5 rounded-lg text-gray-300 hover:border-white/20 transition cursor-pointer">
                <Calendar className="w-3.5 h-3.5 text-[#0DBF4B]" />
                <span className="text-xs">Fecha:</span>
                <input
                  id="input-fixture-date"
                  type="date"
                  value={selectedDate}
                  onChange={(e) => {
                    if (e.target.value) setSelectedDate(e.target.value);
                  }}
                  className="bg-transparent text-white text-xs border-none outline-none font-mono cursor-pointer"
                />
              </label>
            </div>

            {/* THE BIG GREEN BUTTON (#0DBF4B) */}
            <div className="w-full max-w-md pt-2">
              <button
                id="btn-buscar-pronosticos"
                type="button"
                onClick={() => handleBuscarPronosticos()}
                disabled={isLoading}
                className="w-full group relative flex items-center justify-center gap-3 px-8 py-4 md:py-5 rounded-[15px] font-black text-base md:text-lg text-black transition-all duration-300 transform active:scale-95 disabled:opacity-75 disabled:cursor-not-allowed cursor-pointer shadow-lg hover:shadow-xl"
                style={{
                  backgroundColor: '#0DBF4B',
                  boxShadow: '0 0 25px rgba(13, 191, 75, 0.4)',
                }}
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-6 h-6 animate-spin text-black" />
                    <span>ANALIZANDO PARTIDOS...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-6 h-6 text-black stroke-[3]" />
                    <span className="tracking-wide">BUSCAR PRONOSTICOS</span>
                  </>
                )}
              </button>
            </div>

            {/* Live Progress Info during Fetch */}
            {isLoading && progress && (
              <div className="w-full max-w-md bg-black/60 border border-[#0DBF4B]/30 rounded-[12px] p-3 text-left animate-fade-in">
                <div className="flex items-center justify-between text-xs text-gray-300 mb-2">
                  <span className="font-semibold flex items-center gap-1.5">
                    <RefreshCw className="w-3 h-3 animate-spin text-[#0DBF4B]" />
                    {progress.message}
                  </span>
                  {progress.total > 0 && (
                    <span className="font-mono text-emerald-400">
                      {progress.processed}/{progress.total}
                    </span>
                  )}
                </div>
                {progress.total > 0 && (
                  <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#0DBF4B] transition-all duration-300 rounded-full"
                      style={{
                        width: `${Math.min(100, (progress.processed / progress.total) * 100)}%`,
                      }}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        </section>

        {/* Error Notification with Help / Sample option */}
        {errorMessage && (
          <div
            id="error-banner"
            className="bg-red-950/40 border border-red-500/30 p-4 text-red-200 text-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg"
            style={{ borderRadius: '15px' }}
          >
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">{errorMessage}</p>
                <p className="text-xs text-red-300/80 mt-0.5">
                  Si tu límite diario en API-Sports ha expirado o no hay cuotas para esta hora, puedes ver los pronósticos analizados para hoy.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleLoadSamplePicks}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-red-900/60 hover:bg-red-800 border border-red-500/40 text-xs font-bold text-white transition flex-shrink-0 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              Ver Pronósticos del Día
            </button>
          </div>
        )}

        {/* Stats and Filter Bar when picks exist */}
        {picks.length > 0 && (
          <section className="flex flex-col gap-4">
            {/* Metric Summary Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {/* Total Picks */}
              <div
                className="bg-[#1e1e22] border border-white/10 p-3.5 flex items-center justify-between"
                style={{ borderRadius: '15px' }}
              >
                <div>
                  <span className="text-[11px] text-gray-400 font-semibold uppercase block">
                    Partidos Seleccionados
                  </span>
                  <span className="text-xl font-black text-white font-mono">{picks.length}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-[#0DBF4B]/10 border border-[#0DBF4B]/30 flex items-center justify-center text-[#0DBF4B]">
                  <CheckCircle className="w-5 h-5" />
                </div>
              </div>

              {/* Cuota Mínima */}
              <div
                className="bg-[#1e1e22] border border-white/10 p-3.5 flex items-center justify-between"
                style={{ borderRadius: '15px' }}
              >
                <div>
                  <span className="text-[11px] text-gray-400 font-semibold uppercase block">
                    Cuota Mínima
                  </span>
                  <span className="text-xl font-black text-[#F59E0B] font-mono">≥ 1.50</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-[#F59E0B]/10 border border-[#F59E0B]/30 flex items-center justify-center text-[#F59E0B]">
                  <TrendingUp className="w-5 h-5" />
                </div>
              </div>

              {/* Cuota Promedio */}
              <div
                className="bg-[#1e1e22] border border-white/10 p-3.5 flex items-center justify-between"
                style={{ borderRadius: '15px' }}
              >
                <div>
                  <span className="text-[11px] text-gray-400 font-semibold uppercase block">
                    Cuota Promedio
                  </span>
                  <span className="text-xl font-black text-[#0DBF4B] font-mono">@{averageOdd}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-gray-300">
                  <Percent className="w-5 h-5" />
                </div>
              </div>

              {/* Cuota Combinada (Parlay) */}
              <div
                className="bg-[#1e1e22] border border-white/10 p-3.5 flex items-center justify-between"
                style={{ borderRadius: '15px' }}
              >
                <div>
                  <span className="text-[11px] text-gray-400 font-semibold uppercase block">
                    Multiplicador Total
                  </span>
                  <span className="text-xl font-black text-[#F59E0B] font-mono">x{combinedOdd}</span>
                </div>
                <div className="w-9 h-9 rounded-xl bg-[#F59E0B]/10 border border-[#F59E0B]/30 flex items-center justify-center text-[#F59E0B]">
                  <Sparkles className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex items-center gap-1.5 text-xs text-gray-400">
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span className="font-semibold uppercase tracking-wider">Filtrar Mercado:</span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { id: 'todos', label: 'Todos', count: picks.length },
                  {
                    id: 'local',
                    label: 'Gana Local',
                    count: picks.filter((p) => p.pick.includes('Local')).length,
                  },
                  {
                    id: 'visita',
                    label: 'Gana Visita',
                    count: picks.filter((p) => p.pick.includes('Visita')).length,
                  },
                  {
                    id: 'btts',
                    label: 'Ambos Marcan',
                    count: picks.filter((p) => p.market.includes('Ambos') || p.pick.includes('Ambos')).length,
                  },
                  {
                    id: 'over',
                    label: 'Over 2.5',
                    count: picks.filter((p) => p.market.includes('Total') || p.pick.includes('Over')).length,
                  },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveFilter(tab.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition cursor-pointer ${
                      activeFilter === tab.id
                        ? 'bg-[#0DBF4B] text-black shadow-md shadow-[#0DBF4B]/20'
                        : 'bg-[#1e1e22] text-gray-300 hover:text-white border border-white/5'
                    }`}
                  >
                    <span>{tab.label}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        activeFilter === tab.id ? 'bg-black/20 text-black' : 'bg-white/10 text-gray-400'
                      }`}
                    >
                      {tab.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Picks Cards Grid */}
        {filteredPicks.length > 0 ? (
          <section id="picks-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-5">
            {filteredPicks.map((item, idx) => (
              <PickCard key={item.fixtureId} pick={item} index={idx} />
            ))}
          </section>
        ) : hasSearched && !isLoading ? (
          <div
            className="bg-[#1e1e22] border border-white/10 p-8 text-center flex flex-col items-center justify-center gap-3 my-4"
            style={{ borderRadius: '15px' }}
          >
            <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-gray-400">
              <Info className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">Sin pronósticos con los filtros actuales</h3>
            <p className="text-sm text-gray-400 max-w-md">
              No hay partidos que cumplan los criterios seleccionados para esta fecha o categoría.
            </p>
            <button
              onClick={() => setActiveFilter('todos')}
              className="mt-2 px-4 py-2 bg-[#0DBF4B] text-black font-bold text-xs rounded-[10px] hover:bg-[#0dae44] transition cursor-pointer"
            >
              Restablecer Filtros
            </button>
          </div>
        ) : !hasSearched ? (
          /* Empty Initial State: Inviting user to click BUSCAR PRONOSTICOS */
          <section
            className="bg-[#1e1e22] border border-white/5 p-8 md:p-12 text-center flex flex-col items-center justify-center gap-4 my-2"
            style={{ borderRadius: '15px' }}
          >
            <div className="w-16 h-16 rounded-2xl bg-[#0DBF4B]/10 border border-[#0DBF4B]/30 flex items-center justify-center text-[#0DBF4B]">
              <Flame className="w-8 h-8" />
            </div>
            <div className="max-w-md space-y-1.5">
              <h3 className="text-xl font-extrabold text-white">
                Listo para consultar pronósticos
              </h3>
              <p className="text-sm text-gray-400 leading-relaxed">
                Haz clic en el botón verde <strong className="text-[#0DBF4B]">BUSCAR PRONOSTICOS</strong> para
                conectar en tiempo real a la API de fútbol, calcular las probabilidades y seleccionar hasta 8 picks con cuota ≥ 1.50.
              </p>
            </div>
            <button
              onClick={() => handleBuscarPronosticos()}
              className="mt-2 inline-flex items-center gap-2 px-6 py-3 rounded-[12px] bg-[#0DBF4B] text-black font-extrabold text-sm hover:bg-[#0dae44] transition cursor-pointer shadow-lg shadow-[#0DBF4B]/20"
            >
              <Search className="w-4 h-4 stroke-[3]" />
              Empezar Búsqueda
            </button>
          </section>
        ) : null}

        {/* Methodology / Transparency Footnote Card */}
        <section
          className="bg-[#1e1e22] border border-white/5 p-5 text-gray-400 text-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mt-4"
          style={{ borderRadius: '15px' }}
        >
          <div className="flex items-start gap-2.5">
            <Info className="w-4 h-4 text-[#0DBF4B] flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-gray-300 font-semibold">Criterio de Selección de Pronósticos:</p>
              <p className="text-gray-400">
                1. Probabilidad Local &gt; 50% y Cuota &ge; 1.50 &rarr; <strong>Gana Local</strong><br />
                2. Si no, Probabilidad Visita &gt; 50% y Cuota &ge; 1.50 &rarr; <strong>Gana Visita</strong><br />
                3. Si no, Ambos Marcan (Cuota &ge; 1.50) &rarr; <strong>Ambos Marcan</strong><br />
                4. Si no, Over 2.5 Goles (Cuota &ge; 1.50) &rarr; <strong>Over 2.5</strong><br />
                Máximo 8 partidos por jornada.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0 self-end md:self-center">
            <span className="inline-block w-2 h-2 rounded-full bg-[#0DBF4B] animate-pulse" />
            <span className="text-[11px] text-gray-400 font-mono">API-Football v3 Activo</span>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-6 px-4 text-center text-xs text-gray-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} Tu Pronosticos — Aplicación Web Progresiva (PWA)</p>
          <p className="text-gray-600">Juega con responsabilidad. Solo mayores de 18 años.</p>
        </div>
      </footer>
    </div>
  );
}
