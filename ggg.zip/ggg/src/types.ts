export interface ApiTeam {
  id: number;
  name: string;
  logo: string;
}

export interface ApiLeague {
  id: number;
  name: string;
  country: string;
  logo: string;
  flag?: string;
  season?: number;
}

export interface ApiFixtureStatus {
  long: string;
  short: string;
  elapsed?: number;
}

export interface ApiFixture {
  id: number;
  referee?: string | null;
  timezone: string;
  date: string;
  timestamp: number;
  status: ApiFixtureStatus;
}

export interface FixtureResponseItem {
  fixture: ApiFixture;
  league: ApiLeague;
  teams: {
    home: ApiTeam;
    away: ApiTeam;
  };
  goals?: {
    home: number | null;
    away: number | null;
  };
}

export interface PredictionResponseItem {
  predictions: {
    winner?: {
      id: number;
      name: string;
      comment?: string;
    };
    win_or_draw?: boolean;
    under_over?: string | null;
    advice?: string;
    percent?: {
      home: string;
      draw: string;
      away: string;
    };
  };
  comparison?: Record<string, { home: string; away: string }>;
}

export interface OddsBetValue {
  value: string | number;
  odd: string;
}

export interface OddsBet {
  id: number;
  name: string;
  values: OddsBetValue[];
}

export interface OddsBookmaker {
  id: number;
  name: string;
  bets: OddsBet[];
}

export interface OddsResponseItem {
  league: ApiLeague;
  fixture: ApiFixture;
  bookmakers: OddsBookmaker[];
}

export interface ProcessedPick {
  fixtureId: number;
  league: {
    name: string;
    country: string;
    logo: string;
  };
  formattedTime: string;
  rawDate: string;
  status: {
    short: string;
    long: string;
  };
  homeTeam: {
    name: string;
    logo: string;
  };
  awayTeam: {
    name: string;
    logo: string;
  };
  // Probabilities
  probHome: number;
  probDraw: number;
  probAway: number;
  // 1X2 Odds
  odd1: number | null;
  oddX: number | null;
  odd2: number | null;
  // Chosen Pick
  market: string;
  pick: string;
  cuota: number;
  bookmakerName?: string;
  priorityReason: string;
  advice?: string;
}
