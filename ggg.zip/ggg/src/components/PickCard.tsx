import React from 'react';
import { ProcessedPick } from '../types';
import { Trophy, TrendingUp, Sparkles, CheckCircle2 } from 'lucide-react';

interface PickCardProps {
  pick: ProcessedPick;
  index: number;
}

export const PickCard: React.FC<PickCardProps> = ({ pick, index }) => {
  const is1X2 = pick.market.includes('1X2');
  const isHomePick = is1X2 && (pick.pick.includes('Local') || pick.pick.includes(pick.homeTeam.name));
  const isAwayPick = is1X2 && (pick.pick.includes('Visita') || pick.pick.includes(pick.awayTeam.name));

  return (
    <div
      id={`pick-card-${pick.fixtureId}`}
      className="relative flex flex-col justify-between bg-[#1e1e22] border border-white/10 hover:border-[#0DBF4B]/40 transition-all duration-300 shadow-xl hover:shadow-2xl hover:shadow-[#0DBF4B]/5 p-5 md:p-6 text-white group"
      style={{ borderRadius: '15px' }}
    >
      {/* Top Header: Liga | Hora */}
      <div className="flex items-center justify-between pb-3 border-b border-white/5 gap-2">
        <div className="flex items-center gap-2 min-w-0">
          {pick.league.logo ? (
            <img
              src={pick.league.logo}
              alt={pick.league.name}
              className="w-5 h-5 object-contain flex-shrink-0 bg-white/5 rounded-full p-0.5"
              onError={(e) => {
                // Fallback if logo fails
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          ) : (
            <Trophy className="w-4 h-4 text-[#0DBF4B]" />
          )}
          <span className="text-xs font-semibold tracking-wide text-gray-300 truncate uppercase">
            {pick.league.name}
          </span>
          <span className="text-gray-500 font-bold">•</span>
          <span className="text-xs font-mono font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-500/20 px-2 py-0.5 rounded-full flex-shrink-0">
            {pick.formattedTime}
          </span>
        </div>

        {/* Status Badge */}
        <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-white/5 text-gray-400 border border-white/5">
          {pick.status.short === 'NS' ? 'Hoy' : pick.status.short}
        </span>
      </div>

      {/* Matchup: Local VS Visita */}
      <div className="py-4">
        <div className="grid grid-cols-7 items-center gap-2">
          {/* Home Team */}
          <div className="col-span-3 flex flex-col items-center text-center gap-2">
            <div className="relative w-12 h-12 flex items-center justify-center bg-black/40 rounded-full p-1.5 border border-white/10 shadow-inner group-hover:border-white/20 transition">
              {pick.homeTeam.logo ? (
                <img
                  src={pick.homeTeam.logo}
                  alt={pick.homeTeam.name}
                  className="w-8 h-8 object-contain"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-xs font-bold">
                  {pick.homeTeam.name.slice(0, 2)}
                </div>
              )}
            </div>
            <span
              className={`text-sm font-bold leading-tight line-clamp-2 ${
                isHomePick ? 'text-white' : 'text-gray-200'
              }`}
            >
              {pick.homeTeam.name}
            </span>
            <span className="text-[10px] text-gray-400 font-medium uppercase tracking-wider">
              Local
            </span>
          </div>

          {/* VS Divider */}
          <div className="col-span-1 flex flex-col items-center justify-center">
            <span className="text-xs font-black text-gray-400 bg-black/50 border border-white/10 px-2 py-1 rounded-md shadow-sm">
              VS
            </span>
          </div>

          {/* Away Team */}
          <div className="col-span-3 flex flex-col items-center text-center gap-2">
            <div className="relative w-12 h-12 flex items-center justify-center bg-black/40 rounded-full p-1.5 border border-white/10 shadow-inner group-hover:border-white/20 transition">
              {pick.awayTeam.logo ? (
                <img
                  src={pick.awayTeam.logo}
                  alt={pick.awayTeam.name}
                  className="w-8 h-8 object-contain"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-xs font-bold">
                  {pick.awayTeam.name.slice(0, 2)}
                </div>
              )}
            </div>
            <span
              className={`text-sm font-bold leading-tight line-clamp-2 ${
                isAwayPick ? 'text-white' : 'text-gray-200'
              }`}
            >
              {pick.awayTeam.name}
            </span>
            <span className="text-[10px] text-gray-400 font-medium uppercase tracking-wider">
              Visita
            </span>
          </div>
        </div>
      </div>

      {/* Main Pick Showcase Block */}
      <div
        className="my-2 p-3.5 bg-black/50 border border-[#0DBF4B]/30 rounded-[12px] relative overflow-hidden"
      >
        {/* Glow effect */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-[#0DBF4B]/10 rounded-full blur-xl pointer-events-none" />

        {/* Mercado */}
        <div className="flex items-center justify-between gap-2 mb-1.5">
          <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">
            Mercado:
          </span>
          <span className="text-xs font-medium text-gray-300 bg-white/5 px-2 py-0.5 rounded">
            {pick.market}
          </span>
        </div>

        {/* PICK en verde & Cuota en dorado */}
        <div className="flex items-center justify-between gap-3 pt-1">
          {/* PICK en verde */}
          <div className="flex items-center gap-1.5 min-w-0">
            <CheckCircle2 className="w-4 h-4 text-[#0DBF4B] flex-shrink-0" />
            <div className="min-w-0">
              <span className="text-[10px] text-[#0DBF4B]/80 font-bold uppercase block tracking-wider leading-none">
                PICK
              </span>
              <span className="text-sm md:text-base font-extrabold text-[#0DBF4B] tracking-tight truncate block">
                {pick.pick}
              </span>
            </div>
          </div>

          {/* Cuota en dorado */}
          <div className="flex flex-col items-end flex-shrink-0">
            <span className="text-[10px] text-[#F59E0B]/80 font-bold uppercase tracking-wider leading-none">
              Cuota
            </span>
            <span className="text-lg md:text-xl font-black text-[#F59E0B] drop-shadow-sm font-mono">
              @{pick.cuota.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Priority Reason / Insight */}
        {pick.priorityReason && (
          <div className="mt-2.5 pt-2 border-t border-white/5 flex items-center gap-1.5 text-[11px] text-gray-300">
            <Sparkles className="w-3 h-3 text-[#0DBF4B] flex-shrink-0" />
            <span className="truncate">{pick.priorityReason}</span>
          </div>
        )}
      </div>

      {/* Probabilidades Section */}
      <div className="pt-2 pb-1">
        <div className="flex items-center justify-between text-[11px] font-semibold text-gray-400 mb-1.5">
          <span className="flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-gray-400" /> Probabilidades
          </span>
          <div className="flex items-center gap-3 text-[11px] font-mono">
            <span className="text-emerald-400">L: {pick.probHome}%</span>
            <span className="text-gray-400">E: {pick.probDraw}%</span>
            <span className="text-sky-400">V: {pick.probAway}%</span>
          </div>
        </div>

        {/* Segmented probability bar */}
        <div className="w-full h-2 bg-black/60 rounded-full overflow-hidden flex p-0.5 gap-0.5">
          <div
            className="h-full bg-[#0DBF4B] rounded-l-full transition-all duration-500"
            style={{ width: `${pick.probHome}%` }}
            title={`Local: ${pick.probHome}%`}
          />
          <div
            className="h-full bg-gray-600 transition-all duration-500"
            style={{ width: `${pick.probDraw}%` }}
            title={`Empate: ${pick.probDraw}%`}
          />
          <div
            className="h-full bg-sky-500 rounded-r-full transition-all duration-500"
            style={{ width: `${pick.probAway}%` }}
            title={`Visita: ${pick.probAway}%`}
          />
        </div>
      </div>

      {/* Cuotas 1X2 Section */}
      <div className="pt-3 mt-1 border-t border-white/5">
        <div className="flex items-center justify-between text-[11px] font-semibold text-gray-400 mb-1.5">
          <span>Cuotas 1X2</span>
          <span className="text-[10px] text-gray-500">{pick.bookmakerName || 'Oficial'}</span>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          {/* 1 (Local) */}
          <div
            className={`py-1.5 px-2 rounded-[10px] border transition-all ${
              isHomePick
                ? 'bg-[#0DBF4B]/20 border-[#0DBF4B] text-white shadow-sm'
                : 'bg-black/40 border-white/5 text-gray-300 hover:border-white/15'
            }`}
          >
            <div className="text-[10px] font-semibold text-gray-400 uppercase">1 (Local)</div>
            <div
              className={`text-xs font-mono font-bold ${
                isHomePick ? 'text-[#0DBF4B]' : 'text-gray-200'
              }`}
            >
              {pick.odd1 ? pick.odd1.toFixed(2) : '-'}
            </div>
          </div>

          {/* X (Empate) */}
          <div className="py-1.5 px-2 rounded-[10px] bg-black/40 border border-white/5 text-gray-300 hover:border-white/15 transition-all">
            <div className="text-[10px] font-semibold text-gray-400 uppercase">X (Empate)</div>
            <div className="text-xs font-mono font-bold text-gray-200">
              {pick.oddX ? pick.oddX.toFixed(2) : '-'}
            </div>
          </div>

          {/* 2 (Visita) */}
          <div
            className={`py-1.5 px-2 rounded-[10px] border transition-all ${
              isAwayPick
                ? 'bg-[#0DBF4B]/20 border-[#0DBF4B] text-white shadow-sm'
                : 'bg-black/40 border-white/5 text-gray-300 hover:border-white/15'
            }`}
          >
            <div className="text-[10px] font-semibold text-gray-400 uppercase">2 (Visita)</div>
            <div
              className={`text-xs font-mono font-bold ${
                isAwayPick ? 'text-[#0DBF4B]' : 'text-gray-200'
              }`}
            >
              {pick.odd2 ? pick.odd2.toFixed(2) : '-'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
