import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, X } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already installed, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        id="btn-install-pwa"
        onClick={install}
        className="inline-flex items-center gap-2 rounded-full bg-[#0DBF4B]/15 border border-[#0DBF4B]/40 px-3.5 py-1.5 text-xs font-semibold text-[#0DBF4B] hover:bg-[#0DBF4B]/25 hover:border-[#0DBF4B] transition-all cursor-pointer shadow-sm active:scale-95"
        title="Instalar Tu Pronosticos en tu dispositivo"
      >
        <Download className="w-3.5 h-3.5" />
        <span>Instalar App</span>
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          id="btn-install-pwa-ios"
          onClick={() => setShowIOSGuide(true)}
          className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-medium text-gray-300 hover:text-white hover:bg-white/10 transition cursor-pointer"
        >
          <Smartphone className="w-3.5 h-3.5 text-[#0DBF4B]" />
          <span>Instalar en iOS</span>
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-[15px] bg-[#1e1e22] border border-white/10 p-6 shadow-2xl text-white">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-[#0DBF4B]" />
                  Instalar en iPhone / iPad
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="text-gray-400 hover:text-white p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm text-gray-300 space-y-2 leading-relaxed">
                1. Toca el botón <strong>Compartir</strong> en la barra de Safari (el ícono con flecha hacia arriba).<br />
                2. Desplázate hacia abajo y selecciona <strong>Agregar al inicio</strong>.<br />
                3. ¡Listo! Accede a <strong>Tu Pronosticos</strong> desde tu pantalla de inicio como una app nativa.
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-5 w-full rounded-[10px] bg-[#0DBF4B] py-2.5 text-sm font-bold text-black hover:bg-[#0dae44] transition cursor-pointer"
              >
                Entendido
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
