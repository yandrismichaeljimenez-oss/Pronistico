import {
  FixtureResponseItem,
  PredictionResponseItem,
  OddsResponseItem,
  ProcessedPick
} from '../types';

export const RAPID_API_KEY = '769a8efdc3789fad5ab1864f75b4ff78';
export const RAPID_API_HOST = 'v3.football.api-sports.io';
const BASE_URL = 'https://v3.football.api-sports.io';

const HEADERS: HeadersInit = {
  'x-rapidapi-key': RAPID_API_KEY,
  'x-rapidapi-host': RAPID_API_HOST,
};

export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatMatchTime(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  } catch {
    return '18:00';
  }
}

export interface FetchProgress {
  step: 'idle' | 'fixtures' | 'predictions' | 'done' | 'error';
  message: string;
  processed: number;
  total: number;
  picksFound: number;
}

/**
 * Extract odds for 1X2, BTTS, and Over 2.5 across bookmakers
 */
function extractOdds(oddsResponse: OddsResponseItem[]) {
  let odd1: number | null = null;
  let oddX: number | null = null;
  let odd2: number | null = null;
  let oddBTTS: number | null = null;
  let oddOver25: number | null = null;
  let bookmakerName: string | undefined;

  if (!oddsResponse || oddsResponse.length === 0) {
    return { odd1, oddX, odd2, oddBTTS, oddOver25, bookmakerName };
  }

  const bookmakers = oddsResponse[0]?.bookmakers || [];

  for (const b of bookmakers) {
    if (!bookmakerName) bookmakerName = b.name;

    // 1X2 / Match Winner (Bet ID 1)
    if (odd1 === null || oddX === null || odd2 === null) {
      const winnerBet = b.bets?.find(
        (bet) => bet.id === 1 || bet.name?.toLowerCase().includes('winner')
      );
      if (winnerBet?.values) {
        for (const v of winnerBet.values) {
          const val = String(v.value).toLowerCase();
          const parsed = parseFloat(String(v.odd));
          if (!isNaN(parsed)) {
            if (val === 'home' || val === '1') odd1 = parsed;
            else if (val === 'draw' || val === 'x') oddX = parsed;
            else if (val === 'away' || val === '2') odd2 = parsed;
          }
        }
      }
    }

    // Both Teams Score (Bet ID 8)
    if (oddBTTS === null) {
      const bttsBet = b.bets?.find(
        (bet) => bet.id === 8 || bet.name?.toLowerCase().includes('both teams')
      );
      if (bttsBet?.values) {
        const yesVal = bttsBet.values.find((v) => String(v.value).toLowerCase() === 'yes');
        if (yesVal) {
          const parsed = parseFloat(String(yesVal.odd));
          if (!isNaN(parsed)) oddBTTS = parsed;
        }
      }
    }

    // Over 2.5 Goals (Bet ID 5 or name contains 'over/under')
    if (oddOver25 === null) {
      const ouBet = b.bets?.find(
        (bet) =>
          bet.id === 5 ||
          (bet.name?.toLowerCase().includes('over/under') && !bet.name?.toLowerCase().includes('half'))
      );
      if (ouBet?.values) {
        const overVal = ouBet.values.find((v) => {
          const s = String(v.value).toLowerCase();
          return s.includes('over 2.5') || s === 'over 2.5' || s === '2.5';
        });
        if (overVal) {
          const parsed = parseFloat(String(overVal.odd));
          if (!isNaN(parsed)) oddOver25 = parsed;
        }
      }
    }

    // If we have all needed values, stop scanning bookmakers
    if (odd1 !== null && oddX !== null && odd2 !== null && oddBTTS !== null && oddOver25 !== null) {
      break;
    }
  }

  return { odd1, oddX, odd2, oddBTTS, oddOver25, bookmakerName };
}

/**
 * Prioritization Algorithm:
 * - Must have cuota >= 1.50
 * - 1. Gana Local if probHome > 50% & odd1 >= 1.50
 * - 2. Else Gana Visita if probAway > 50% & odd2 >= 1.50
 * - 3. Else Ambos Marcan if oddBTTS >= 1.50
 * - 4. Else Over 2.5 if oddOver25 >= 1.50
 */
function evaluatePick(
  fixtureItem: FixtureResponseItem,
  predItem: PredictionResponseItem | null,
  oddsItem: OddsResponseItem[] | null
): ProcessedPick | null {
  const fixture = fixtureItem.fixture;
  const league = fixtureItem.league;
  const teams = fixtureItem.teams;

  // Extract probabilities
  const percent = predItem?.predictions?.percent;
  const probHome = percent?.home ? parseInt(percent.home.replace('%', ''), 10) || 33 : 33;
  const probDraw = percent?.draw ? parseInt(percent.draw.replace('%', ''), 10) || 34 : 34;
  const probAway = percent?.away ? parseInt(percent.away.replace('%', ''), 10) || 33 : 33;

  const { odd1, oddX, odd2, oddBTTS, oddOver25, bookmakerName } = extractOdds(oddsItem || []);

  let chosenMarket = '';
  let chosenPick = '';
  let chosenOdd = 0;
  let priorityReason = '';

  // Rule 1: Prioriza Gana Local si probabilidad home > 50%
  if (probHome > 50 && odd1 !== null && odd1 >= 1.50) {
    chosenMarket = 'Resultado Final (1X2)';
    chosenPick = `Gana Local (${teams.home.name})`;
    chosenOdd = odd1;
    priorityReason = `Probabilidad local dominante (${probHome}%) con cuota atractiva`;
  }
  // Rule 2: Si no, Gana Visita si away > 50%
  else if (probAway > 50 && odd2 !== null && odd2 >= 1.50) {
    chosenMarket = 'Resultado Final (1X2)';
    chosenPick = `Gana Visita (${teams.away.name})`;
    chosenOdd = odd2;
    priorityReason = `Probabilidad visitante dominante (${probAway}%) con cuota atractiva`;
  }
  // Rule 3: Si no, Ambos Marcan
  else if (oddBTTS !== null && oddBTTS >= 1.50) {
    chosenMarket = 'Ambos Equipos Anotan (BTTS)';
    chosenPick = 'Ambos Marcan (Sí)';
    chosenOdd = oddBTTS;
    priorityReason = 'Partido con alta tendencia ofensiva en ambos bandos';
  }
  // Rule 4: Si no, Over 2.5
  else if (oddOver25 !== null && oddOver25 >= 1.50) {
    chosenMarket = 'Total de Goles';
    chosenPick = 'Más de 2.5 Goles (+2.5)';
    chosenOdd = oddOver25;
    priorityReason = 'Previsión de encuentro dinámico con más de 2.5 anotaciones';
  }

  // Strictly enforce cuota >= 1.50
  if (!chosenPick || chosenOdd < 1.50) {
    return null;
  }

  return {
    fixtureId: fixture.id,
    league: {
      name: league.name,
      country: league.country,
      logo: league.logo,
    },
    formattedTime: formatMatchTime(fixture.date),
    rawDate: fixture.date,
    status: {
      short: fixture.status.short,
      long: fixture.status.long,
    },
    homeTeam: {
      name: teams.home.name,
      logo: teams.home.logo,
    },
    awayTeam: {
      name: teams.away.name,
      logo: teams.away.logo,
    },
    probHome,
    probDraw,
    probAway,
    odd1: odd1 || (chosenMarket.includes('1X2') && chosenPick.includes('Local') ? chosenOdd : null),
    oddX: oddX,
    odd2: odd2 || (chosenMarket.includes('1X2') && chosenPick.includes('Visita') ? chosenOdd : null),
    market: chosenMarket,
    pick: chosenPick,
    cuota: chosenOdd,
    bookmakerName: bookmakerName || 'Bookmaker Oficial',
    priorityReason,
    advice: predItem?.predictions?.advice,
  };
}

/**
 * Fetch predictions and odds for today's fixtures
 */
export async function fetchDailyPicks(
  dateParam?: string,
  onProgress?: (progress: FetchProgress) => void
): Promise<{ picks: ProcessedPick[]; error?: string; remainingRequests?: number }> {
  const dateStr = dateParam || getTodayDateString();

  onProgress?.({
    step: 'fixtures',
    message: `Consultando partidos programados para ${dateStr}...`,
    processed: 0,
    total: 0,
    picksFound: 0,
  });

  try {
    // 1. Fetch fixtures for date
    const fixturesUrl = `${BASE_URL}/fixtures?date=${dateStr}`;
    const fixturesRes = await fetch(fixturesUrl, { headers: HEADERS });

    if (!fixturesRes.ok) {
      throw new Error(`Error en servidor de API-Football: ${fixturesRes.status} ${fixturesRes.statusText}`);
    }

    const fixturesData = await fixturesRes.json();

    if (fixturesData.errors && Object.keys(fixturesData.errors).length > 0) {
      const errorMsg = Object.values(fixturesData.errors).join(', ');
      if (errorMsg.toLowerCase().includes('limit')) {
        throw new Error('Has alcanzado el límite diario de peticiones de tu cuenta en API-Sports (100 peticiones/día).');
      }
      throw new Error(errorMsg);
    }

    const allFixtures: FixtureResponseItem[] = fixturesData.response || [];

    if (allFixtures.length === 0) {
      return {
        picks: [],
        error: `No se encontraron partidos para la fecha ${dateStr}.`,
      };
    }

    // Sort to prioritize top leagues or scheduled/in-progress matches
    // Priority leagues: Serie A, Premier League, MLS, La Liga, Bundesliga, Ligue 1, Primera División, etc.
    const priorityLeagues = [
      'serie a',
      'premier league',
      'la liga',
      'major league soccer',
      'bundesliga',
      'ligue 1',
      'copa libertadores',
      'copa sudamericana',
      'liga profesional argentina',
      'primera division',
      'brasileiro',
      'championship',
      'eredivisie',
      'primeira liga',
    ];

    const sortedFixtures = [...allFixtures].sort((a, b) => {
      const aName = a.league.name.toLowerCase();
      const bName = b.league.name.toLowerCase();
      const aPri = priorityLeagues.some((p) => aName.includes(p)) ? 1 : 0;
      const bPri = priorityLeagues.some((p) => bName.includes(p)) ? 1 : 0;
      if (bPri !== aPri) return bPri - aPri;
      // Then prioritize not finished games
      const aFinished = a.fixture.status.short === 'FT' ? 0 : 1;
      const bFinished = b.fixture.status.short === 'FT' ? 0 : 1;
      return bFinished - aFinished;
    });

    const qualifyingPicks: ProcessedPick[] = [];
    const maxPicks = 8;
    // Inspect up to 25 candidate fixtures to keep within the 100 daily quota
    const candidateFixtures = sortedFixtures.slice(0, 25);

    let processedCount = 0;

    for (const fixtureItem of candidateFixtures) {
      if (qualifyingPicks.length >= maxPicks) {
        break;
      }

      processedCount++;
      const fixtureId = fixtureItem.fixture.id;
      const matchLabel = `${fixtureItem.teams.home.name} vs ${fixtureItem.teams.away.name}`;

      onProgress?.({
        step: 'predictions',
        message: `Analizando ${matchLabel} (${qualifyingPicks.length}/${maxPicks} picks encontrados)...`,
        processed: processedCount,
        total: candidateFixtures.length,
        picksFound: qualifyingPicks.length,
      });

      try {
        // Fetch predictions and odds in parallel for this fixture
        const [predRes, oddsRes] = await Promise.all([
          fetch(`${BASE_URL}/predictions?fixture=${fixtureId}`, { headers: HEADERS }).catch(() => null),
          fetch(`${BASE_URL}/odds?fixture=${fixtureId}`, { headers: HEADERS }).catch(() => null),
        ]);

        let predData: PredictionResponseItem | null = null;
        if (predRes && predRes.ok) {
          const json = await predRes.json();
          if (json.response && json.response.length > 0) {
            predData = json.response[0];
          }
        }

        let oddsData: OddsResponseItem[] | null = null;
        if (oddsRes && oddsRes.ok) {
          const json = await oddsRes.json();
          if (json.response && json.response.length > 0) {
            oddsData = json.response;
          }
        }

        // Evaluate according to user's criteria
        const pick = evaluatePick(fixtureItem, predData, oddsData);
        if (pick) {
          qualifyingPicks.push(pick);
        }
      } catch {
        // Continue scanning next fixture
      }

      // Brief delay to avoid aggressive rate limit bursts (10 req/min free plan)
      await new Promise((r) => setTimeout(r, 200));
    }

    onProgress?.({
      step: 'done',
      message: `¡Análisis completado! Se encontraron ${qualifyingPicks.length} pronósticos destacados con cuota ≥ 1.50.`,
      processed: processedCount,
      total: candidateFixtures.length,
      picksFound: qualifyingPicks.length,
    });

    // Cache successful results in localStorage
    if (qualifyingPicks.length > 0) {
      try {
        localStorage.setItem(`tu_pronosticos_${dateStr}`, JSON.stringify(qualifyingPicks));
      } catch {
        // ignore storage errors
      }
    }

    return { picks: qualifyingPicks };
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Error inesperado al conectar con API-Football.';
    onProgress?.({
      step: 'error',
      message,
      processed: 0,
      total: 0,
      picksFound: 0,
    });

    // Check if we have cached picks for this date
    try {
      const cached = localStorage.getItem(`tu_pronosticos_${dateStr}`);
      if (cached) {
        const parsed = JSON.parse(cached) as ProcessedPick[];
        if (parsed.length > 0) {
          return { picks: parsed, error: `${message} (Mostrando resultados previos en caché)` };
        }
      }
    } catch {
      // ignore
    }

    return { picks: [], error: message };
  }
}

/**
 * High quality curated fallback picks in case daily API limits (100/day) are depleted,
 * ensuring users can always test and preview the app seamlessly.
 */
export const SAMPLE_FALLBACK_PICKS: ProcessedPick[] = [
  {
    fixtureId: 1492371,
    league: {
      name: 'Serie A',
      country: 'Brasil',
      logo: 'https://media.api-sports.io/football/leagues/71.png',
    },
    formattedTime: '20:00',
    rawDate: '2026-09-14T23:00:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Bahia',
      logo: 'https://media.api-sports.io/football/teams/118.png',
    },
    awayTeam: {
      name: 'Remo',
      logo: 'https://media.api-sports.io/football/teams/1198.png',
    },
    probHome: 55,
    probDraw: 25,
    probAway: 20,
    odd1: 1.82,
    oddX: 3.50,
    odd2: 4.60,
    market: 'Resultado Final (1X2)',
    pick: 'Gana Local (Bahia)',
    cuota: 1.82,
    bookmakerName: 'William Hill',
    priorityReason: 'Probabilidad local dominante (55% > 50%) con cuota sólida de 1.82',
    advice: 'Combo Double chance : Bahia or draw and +1.5 goals',
  },
  {
    fixtureId: 1490480,
    league: {
      name: 'Major League Soccer',
      country: 'USA',
      logo: 'https://media.api-sports.io/football/leagues/253.png',
    },
    formattedTime: '19:30',
    rawDate: '2026-09-14T23:30:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Inter Miami',
      logo: 'https://media.api-sports.io/football/teams/9568.png',
    },
    awayTeam: {
      name: 'Atlanta United',
      logo: 'https://media.api-sports.io/football/teams/1608.png',
    },
    probHome: 62,
    probDraw: 20,
    probAway: 18,
    odd1: 1.75,
    oddX: 3.80,
    odd2: 4.25,
    market: 'Resultado Final (1X2)',
    pick: 'Gana Local (Inter Miami)',
    cuota: 1.75,
    bookmakerName: 'Bet365',
    priorityReason: 'Alta probabilidad de victoria local (62% > 50%) con cuota 1.75',
    advice: 'Winner : Inter Miami',
  },
  {
    fixtureId: 1492761,
    league: {
      name: 'Premier Division',
      country: 'Irlanda',
      logo: 'https://media.api-sports.io/football/leagues/357.png',
    },
    formattedTime: '18:45',
    rawDate: '2026-09-14T18:45:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Shamrock Rovers',
      logo: 'https://media.api-sports.io/football/teams/448.png',
    },
    awayTeam: {
      name: 'Derry City',
      logo: 'https://media.api-sports.io/football/teams/444.png',
    },
    probHome: 38,
    probDraw: 32,
    probAway: 30,
    odd1: 2.10,
    oddX: 3.20,
    odd2: 3.40,
    market: 'Ambos Equipos Anotan (BTTS)',
    pick: 'Ambos Marcan (Sí)',
    cuota: 1.88,
    bookmakerName: 'Betfair',
    priorityReason: 'Duelo parejo con alta efectividad goleadora en ambas escuadras',
    advice: 'Both teams to score : YES',
  },
  {
    fixtureId: 1493129,
    league: {
      name: 'Liga Profesional Argentina',
      country: 'Argentina',
      logo: 'https://media.api-sports.io/football/leagues/128.png',
    },
    formattedTime: '21:00',
    rawDate: '2026-09-14T21:00:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Boca Juniors',
      logo: 'https://media.api-sports.io/football/teams/451.png',
    },
    awayTeam: {
      name: 'Estudiantes LP',
      logo: 'https://media.api-sports.io/football/teams/450.png',
    },
    probHome: 52,
    probDraw: 28,
    probAway: 20,
    odd1: 1.95,
    oddX: 3.10,
    odd2: 3.90,
    market: 'Resultado Final (1X2)',
    pick: 'Gana Local (Boca Juniors)',
    cuota: 1.95,
    bookmakerName: '1xBet',
    priorityReason: 'Probabilidad de localía superior al 50% con cuota premium de 1.95',
    advice: 'Winner : Boca Juniors',
  },
  {
    fixtureId: 1494582,
    league: {
      name: 'Championship',
      country: 'Inglaterra',
      logo: 'https://media.api-sports.io/football/leagues/40.png',
    },
    formattedTime: '20:00',
    rawDate: '2026-09-14T19:00:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Leeds United',
      logo: 'https://media.api-sports.io/football/teams/63.png',
    },
    awayTeam: {
      name: 'Watford',
      logo: 'https://media.api-sports.io/football/teams/38.png',
    },
    probHome: 35,
    probDraw: 25,
    probAway: 40,
    odd1: 2.25,
    oddX: 3.40,
    odd2: 2.90,
    market: 'Total de Goles',
    pick: 'Más de 2.5 Goles (+2.5)',
    cuota: 1.80,
    bookmakerName: 'Betfair',
    priorityReason: 'Historial de alta tasa de goles en enfrentamientos directos (+2.5)',
    advice: 'Over 2.5 goals',
  },
  {
    fixtureId: 1495831,
    league: {
      name: 'Primeira Liga',
      country: 'Portugal',
      logo: 'https://media.api-sports.io/football/leagues/94.png',
    },
    formattedTime: '20:15',
    rawDate: '2026-09-14T19:15:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Sporting CP',
      logo: 'https://media.api-sports.io/football/teams/228.png',
    },
    awayTeam: {
      name: 'Braga',
      logo: 'https://media.api-sports.io/football/teams/217.png',
    },
    probHome: 58,
    probDraw: 22,
    probAway: 20,
    odd1: 1.65,
    oddX: 3.90,
    odd2: 5.00,
    market: 'Resultado Final (1X2)',
    pick: 'Gana Local (Sporting CP)',
    cuota: 1.65,
    bookmakerName: 'Pinnacle',
    priorityReason: 'Probabilidad local de 58% (>50%) con cuota segura de 1.65',
    advice: 'Combo Double chance : Sporting CP or draw and +1.5 goals',
  },
  {
    fixtureId: 1496014,
    league: {
      name: 'Liga MX',
      country: 'México',
      logo: 'https://media.api-sports.io/football/leagues/262.png',
    },
    formattedTime: '22:00',
    rawDate: '2026-09-14T22:00:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Tigres UANL',
      logo: 'https://media.api-sports.io/football/teams/2287.png',
    },
    awayTeam: {
      name: 'Toluca',
      logo: 'https://media.api-sports.io/football/teams/2290.png',
    },
    probHome: 30,
    probDraw: 35,
    probAway: 35,
    odd1: 2.15,
    oddX: 3.30,
    odd2: 3.10,
    market: 'Ambos Equipos Anotan (BTTS)',
    pick: 'Ambos Marcan (Sí)',
    cuota: 1.72,
    bookmakerName: 'Bet365',
    priorityReason: 'Tendencia en últimos 5 encuentros con goles en ambas porterías',
    advice: 'Both teams to score : YES',
  },
  {
    fixtureId: 1497220,
    league: {
      name: 'Copa do Brasil',
      country: 'Brasil',
      logo: 'https://media.api-sports.io/football/leagues/73.png',
    },
    formattedTime: '21:30',
    rawDate: '2026-09-14T21:30:00+00:00',
    status: {
      short: 'NS',
      long: 'Not Started',
    },
    homeTeam: {
      name: 'Fluminense',
      logo: 'https://media.api-sports.io/football/teams/124.png',
    },
    awayTeam: {
      name: 'Corinthians',
      logo: 'https://media.api-sports.io/football/teams/131.png',
    },
    probHome: 20,
    probDraw: 25,
    probAway: 55,
    odd1: 3.60,
    oddX: 3.15,
    odd2: 2.10,
    market: 'Resultado Final (1X2)',
    pick: 'Gana Visita (Corinthians)',
    cuota: 2.10,
    bookmakerName: 'William Hill',
    priorityReason: 'Probabilidad de visita superior al 50% (55%) con cuota de gran valor 2.10',
    advice: 'Winner : Corinthians',
  },
];
